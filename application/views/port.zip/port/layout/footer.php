
    <footer>
      © <script>document.write(new Date().getFullYear())</script>
      <a href="<?php echo base_url(); ?>">Rstyping.com</a>
    </footer>
  </body>
  <script src="<?php echo base_url(); ?>optimum/ports/js/jquery.min.js"></script>

</html>
